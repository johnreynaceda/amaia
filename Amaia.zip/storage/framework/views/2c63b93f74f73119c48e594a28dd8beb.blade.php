<div class="">
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500 w-64" wire:model="maintenance_id" name="maintenance_id" id="68aae59dbc804b24c718957391443318">
         <option>Select an option</option>
                                                    <option value="1">PLUMBING</option>     </select>

    
                </div>
