<div>
    <div>
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\resources\views/livewire/admin/gate-pass-request-list.blade.php ENDPATH**/ ?>