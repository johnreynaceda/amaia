
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <?php echo WireUi::directives()->scripts(attributes: []); ?>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</head>

<body class="font-sans antialiased relative" x-data="app()">
    <div class="fixed bg-gray-800 top-0 left-0 bottom-0  right-0">
        <img src="<?php echo e(asset('images/page_bg.jpg')); ?>" class="h-full w-full opacity-50 object-cover" alt="">
    </div>
    <div>
        <div class="p-5 relative flex justify-center items-center 2xl:hidden">
            <img src="<?php echo e(asset('images/amaia_logo.png')); ?>" class="xl:h-24 h-20 relative z-10" alt="">
        </div>

        <div class="p-5 relative  2xl:block hidden">
            <img src="<?php echo e(asset('images/amaia_logo.png')); ?>" class="xl:h-24 h-20 relative z-10" alt="">
        </div>
        <section>
            <div class="2xl:py-24 py-10 bg-white">
                <div class="relative px-8">
                    <div class="max-w-3xl text-center lg:text-left">
                        <div class="max-w-xl mx-auto text-center lg:p-10 lg:text-left">
                            <div>
                                <p class="text-2xl font-black tracking-tight text-white sm:text-4xl">
                                    Hello,
                                </p>
                                <p class="text-2xl font-black tracking-tight text-white sm:text-5xl">
                                    Welcome Back!
                                </p>

                            </div>

                            <div
                                class="flex flex-col items-center mb-5 justify-center gap-3 mt-10 2xl:mt-16 lg:flex-row lg:justify-start">
                                <p class="text-gray-300">Please enter your Amaia account.</p>

                            </div>
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>

                                <div class="flex flex-col space-y-5">
                                    <?php if (isset($component)) { $__componentOriginalf2cba1c7f87bbadef8ee9a6866b4816e = $component; } ?>
<?php $component = WireUi\View\Components\Input::resolve(['icon' => 'user'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Input::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '2xl:h-12 ','placeholder' => 'Email address','name' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email')),'required' => true,'autofocus' => true,'autocomplete' => 'username']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2cba1c7f87bbadef8ee9a6866b4816e)): ?>
<?php $component = $__componentOriginalf2cba1c7f87bbadef8ee9a6866b4816e; ?>
<?php unset($__componentOriginalf2cba1c7f87bbadef8ee9a6866b4816e); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal0492513cc0d3c214a5ed582317f74f12 = $component; } ?>
<?php $component = WireUi\View\Components\Inputs\PasswordInput::resolve(['icon' => 'key'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('inputs.password'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(WireUi\View\Components\Inputs\PasswordInput::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '2xl:h-12 ','placeholder' => 'Password','name' => 'password','required' => true,'autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0492513cc0d3c214a5ed582317f74f12)): ?>
<?php $component = $__componentOriginal0492513cc0d3c214a5ed582317f74f12; ?>
<?php unset($__componentOriginal0492513cc0d3c214a5ed582317f74f12); ?>
<?php endif; ?>

                                </div>

                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'my-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'my-5']); ?>
                                    <?php echo e(__('Sign In')); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

                            </form>
                            <div class="relative">
                                <div class="absolute inset-0 flex items-center">
                                    <div class="w-full border-t-2 border-gray-300"></div>
                                </div>
                            </div>
                            <div class="text-right my-5">
                                <span class="text-sm 2xl:text-md">Don't Have an Account? <a
                                        href="<?php echo e(route('register')); ?>"
                                        class="text-white hover:text-cyan-500 2xl:hover:text-main">Register
                                        here.</a></span>
                            </div>

                            <div class="text-left">
                                <span class="text-sm text-gray-200 2xl:text-md">Visiting? Please select and Fill up
                                    the form
                                    provided.</span>
                                <div class="mt-3 flex space-x-3 justify-center 2xl:justify-start items-center">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pass-request', [])->html();
} elseif ($_instance->childHasBeenRendered('LHLm5Qt')) {
    $componentId = $_instance->getRenderedChildComponentId('LHLm5Qt');
    $componentTag = $_instance->getRenderedChildComponentTagName('LHLm5Qt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LHLm5Qt');
} else {
    $response = \Livewire\Livewire::mount('pass-request', []);
    $html = $response->html();
    $_instance->logRenderedChild('LHLm5Qt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\resources\views/auth/login.blade.php ENDPATH**/ ?>