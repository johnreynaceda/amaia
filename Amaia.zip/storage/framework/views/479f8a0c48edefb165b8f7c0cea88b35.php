<span class="outline-none inline-flex justify-center items-center group rounded gap-x-1 text-xs font-semibold px-2.5 py-0.5 text-white bg-negative-500 dark:bg-negative-700" 2xs="2xs">
    
    3

    </span>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/290ce20857f3463f3780f7304f6eb78f.blade.php ENDPATH**/ ?>