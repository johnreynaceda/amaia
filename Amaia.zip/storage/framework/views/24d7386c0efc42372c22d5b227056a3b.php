<span class="outline-none inline-flex justify-center items-center group rounded gap-x-1 text-xs font-semibold px-2.5 py-0.5 text-white bg-gray-500 dark:bg-gray-700 font-bold">
    
    3

    </span>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/0de6af2cfc5f7bd59d2f39a012a07bc3.blade.php ENDPATH**/ ?>