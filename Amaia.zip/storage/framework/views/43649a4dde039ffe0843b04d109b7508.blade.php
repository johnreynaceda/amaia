<a wire:loading.attr="disabled" wire:loading.class="!cursor-wait" href="http://127.0.0.1:8000/guest/resident-satisfaction%20%20" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-slate-600 text-slate-600 border border-slate-600 hover:bg-slate-200
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 dark:text-slate-400
    dark:border-slate-400 font-bold">
    
    RESIDENT SATISFACTION

    
    </a>
