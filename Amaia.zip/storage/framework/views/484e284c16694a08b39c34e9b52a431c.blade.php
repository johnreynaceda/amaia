<div class="">
    
    <select class="form-select block w-full pl-3 pr-10 py-2 text-base sm:text-sm shadow-sm
                rounded-md border bg-white focus:ring-1 focus:outline-none
                dark:bg-secondary-800 dark:border-secondary-600 dark:text-secondary-400 border-secondary-300 focus:ring-primary-500 focus:border-primary-500 w-64" wire:model="amenity_type" name="amenity_type" id="183b9a30f6d31ddaeafb5b50b50010d3">
         <option>Select an option</option>
                                                    <option value="1">Swimming Pool</option>     </select>

    
                </div>
