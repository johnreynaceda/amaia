<div
    x-data="wireui_timepicker({
        model: window.Livewire.find('LLE4HAPkgzUsXOoLptP9').entangle('request_time'),
        config: {
            isLazy:   false,
            interval: 10,
            format:   '12',
            is12H:    true,
            readonly: false,
            disabled: false,
        },
    })"
    wire:key="timepicker::request_time" class="w-full relative"
>
    <div class="relative">
        <div class="">
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" x-model="input" x-on:input.debounce.150ms="onInput($event.target.value)" x-on:blur="emitInput" placeholder="Request Time" name="request_time" id="ece3cd60309fb22353c15734734484bd" />

                    <div class="absolute inset-y-0 right-3 z-5 flex items-center justify-center">
                    <div class="flex items-center gap-x-2 my-auto">
                        <svg class="cursor-pointer w-4 h-4 hover:text-negative-500 transition-colors ease-in-out duration-150" x-cloak="x-cloak" x-show="!config.readonly &amp;&amp; !config.disabled &amp;&amp; input" x-on:click="clearInput" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
</svg>

                        <svg class="cursor-pointer w-5 h-5 text-gray-400 dark:text-gray-600" x-show="!config.readonly &amp;&amp; !config.disabled" x-on:click="toggle" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
</svg>
                    </div>
                </div>
            </div>

    
                </div>
    </div>

    <div class="fixed inset-0 z-20 flex items-end sm:z-10 sm:absolute sm:inset-auto transition-all ease-linear duration-150 "
    style="display: none"
    x-cloak
    x-show="popover"
    x-ref="popover"
    x-on:click.outside="close"
    x-on:keydown.escape.window="handleEscape">
    <div class="fixed inset-0 transition-opacity bg-secondary-400 bg-opacity-60 sm:hidden dark:bg-secondary-700 dark:bg-opacity-60"
        x-show="popover"
        x-transition:enter="ease-out duration-300"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="ease-in duration-200"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        x-on:click="close"
        aria-hidden="true">
    </div>

    <div
        class="w-full rounded-t-md sm:rounded-xl border border-secondary-200 bg-white shadow-lg dark:bg-secondary-800 dark:border-secondary-600 transition-all relative overflow-hidden p-2.5" x-on:keydown.tab.prevent="$event.shiftKey || getNextFocusable().focus()" x-on:keydown.arrow-down.prevent="$event.shiftKey || getNextFocusable().focus()" x-on:keydown.shift.tab.prevent="getPrevFocusable().focus()" x-on:keydown.arrow-up.prevent="getPrevFocusable().focus()"
        x-show="popover"
        tabindex="-1"
        x-transition:enter="ease-out duration-300"
        x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
        x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
        x-transition:leave="ease-in duration-200"
        x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
        x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95">
        <div class="">
            <div class="flex justify-between items-end mb-1">
                            <label class="block text-sm font-medium text-gray-700 dark:text-gray-400">
    Select time
</label>
            
                    </div>
    
    <div class="relative rounded-md  shadow-sm ">
        
        <input type="text" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm" tabindex="0" x-model="search" x-bind:placeholder="input ? input : '12:00'" x-ref="search" x-on:input.debounce.150ms="onSearch($event.target.value)" />

            </div>

    
    </div>

        <ul class="mt-1 w-full h-64 sm:h-32 pb-1 pt-2 overflow-y-auto soft-scrollbar">
            <template x-for="time in filteredTimes">
                <li class="group rounded-md focus:outline-none focus:bg-primary-100 hover:text-white
                            hover:bg-primary-600 cursor-pointer select-none relative py-2 pl-2 pr-9
                            dark:hover:bg-secondary-700"
                    :class="{
                        'text-primary-600 dark:text-secondary-400':   input === time.value,
                        'text-secondary-700 dark:text-secondary-400': input !== time.value,
                    }"
                    tabindex="0"
                    x-on:keydown.enter="selectTime(time)"
                    x-on:click="selectTime(time)">
                    <span x-text="time.label" class="font-normal block truncate"></span>
                    <span
                        class="
                            absolute text-primary-600 group-hover:text-white inset-y-0
                            right-0 flex items-center pr-4 dark:text-secondary-400
                        "
                        x-show="input === time.value">
                        <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
</svg>
                    </span>
                </li>
            </template>
        </ul>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/36993964ebfaf45de75bdbc7da4bb3cd.blade.php ENDPATH**/ ?>