<div>

    <div>
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\resources\views/livewire/admin/home.blade.php ENDPATH**/ ?>