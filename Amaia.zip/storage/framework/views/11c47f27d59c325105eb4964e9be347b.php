<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" wire:target="submitComplaint" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-teal-500 text-white bg-teal-500 hover:bg-teal-600 hover:ring-teal-600
    dark:ring-offset-slate-800 dark:bg-teal-700 dark:ring-teal-700
    dark:hover:bg-teal-600 dark:hover:ring-teal-600 font-semibold" wire:click="submitComplaint">
    
    Submit

            <svg class="w-4 h-4 shrink-0" wire:loading.remove="wire:loading.remove" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
</svg>
    
            <svg class="animate-spin w-4 h-4 shrink-0"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
                            wire:target="submitComplaint"
                        wire:loading.delay>
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/bb953f891242cef95b8964399018978a.blade.php ENDPATH**/ ?>