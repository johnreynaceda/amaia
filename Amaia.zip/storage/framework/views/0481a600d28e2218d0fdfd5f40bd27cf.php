<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed gap-x-2 text-sm px-4 py-2     ring-primary-600 text-primary-600 hover:bg-primary-100
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 dark:ring-primary-700 h-full rounded-l-md" x-hold.click.delay.repeat.100ms="minus" x-on:keydown.enter="minus" x-bind:disabled="disableMinus">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4" />
</svg>
    
    

    
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/adaa1ebb745b897156f90d9e093e0486.blade.php ENDPATH**/ ?>