<div x-data="wireui_inputs_number({
    disabled: false,
    readonly: false,
})" >
    <div class="">
    
    <div class="relative rounded-md  shadow-sm ">
                    <div class="absolute inset-y-0 left-0 flex items-center p-0.5">
                <button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed gap-x-2 text-sm px-4 py-2     ring-primary-600 text-primary-600 hover:bg-primary-100
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 dark:ring-primary-700 h-full rounded-l-md" x-hold.click.delay.repeat.100ms="minus" x-on:keydown.enter="minus" x-bind:disabled="disableMinus">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4" />
</svg>
    
    

    
    </button>
            </div>
        
        <input type="number" autocomplete="off" class="placeholder-secondary-400 dark:bg-secondary-800 dark:text-secondary-400 dark:placeholder-secondary-500 border border-secondary-300 focus:ring-primary-500 focus:border-primary-500 dark:border-secondary-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm text-center appearance-number-none" x-ref="input" inputmode="numeric" x-on:keydown.up.prevent="plus" x-on:keydown.down.prevent="minus" wire:model="total_persons" name="total_persons" id="a959c9e698c661250f63ebcbcdeed549" />

                    <div class="absolute inset-y-0 right-0 flex items-center p-0.5">
                <button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed gap-x-2 text-sm px-4 py-2     ring-primary-600 text-primary-600 hover:bg-primary-100
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 dark:ring-primary-700 h-full rounded-r-md" x-hold.click.delay.repeat.100ms="plus" x-on:keydown.enter="plus" x-bind:disabled="disablePlus">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
</svg>
    
    

    
    </button>
            </div>
            </div>

    
                </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/890c308f9e01faab248d550e2178c488.blade.php ENDPATH**/ ?>