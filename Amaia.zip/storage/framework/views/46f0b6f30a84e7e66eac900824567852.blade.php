<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     text-slate-500 hover:bg-slate-100 ring-slate-200 dark:text-slate-400
    dark:hover:bg-slate-700 dark:ring-slate-600 dark:ring-offset-slate-700" wire:click="closeModal">
    
    Cancel

    
    </button>
