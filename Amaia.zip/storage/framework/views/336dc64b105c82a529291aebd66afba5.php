<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-slate-600 text-slate-900 hover:bg-slate-200 dark:text-slate-400
    dark:ring-offset-slate-800 dark:hover:bg-slate-700 dark:ring-dark-700" secondary="secondary">
    
    Secondary

    
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/57f01ed93213c580f2b20487bdbdeb76.blade.php ENDPATH**/ ?>