<?php echo e($getRecord()->created_at); ?>

<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\resources\views/guest/filament/date.blade.php ENDPATH**/ ?>