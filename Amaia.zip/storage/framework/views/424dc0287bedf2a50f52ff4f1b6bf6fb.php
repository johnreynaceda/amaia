<div class="">
    
    <div class="relative rounded-md  shadow-sm ">
                    <div class="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none
                text-negative-500">
                                    <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
</svg>
                            </div>
        
        <input type="text" autocomplete="username" class="text-negative-900 dark:text-negative-600 placeholder-negative-300 dark:placeholder-negative-500 border border-negative-300 focus:ring-negative-500 focus:border-negative-500 dark:bg-secondary-800 dark:border-negative-600 form-input block w-full sm:text-sm rounded-md transition ease-in-out duration-100 focus:outline-none shadow-sm pl-8 pr-8 2xl:h-12" placeholder="Email address" name="email" value="foduge@mailinator.com" required="required" autofocus="autofocus" id="0c83f57c786a0b4a39efab23731c7ebc" />

                    <div class="absolute inset-y-0 right-0 pr-2.5 flex items-center pointer-events-none
                text-negative-500">
                                    <svg class="w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
</svg>
                            </div>
            </div>

    
            <p class="mt-2 text-sm text-negative-600">
        These credentials do not match our records.
    </p>
    </div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/d6e4dcf5bfb01bb5dc0c76bba93da6dc.blade.php ENDPATH**/ ?>