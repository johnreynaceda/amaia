<span class="outline-none inline-flex justify-center items-center group rounded gap-x-1 text-xs font-semibold px-2.5 py-0.5 text-white bg-gray-500 dark:bg-gray-700 font-bold">
    
    6

    </span>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\Amaia\storage\framework\views/ec0c1877bc6f257343c08a7a7f81b807.blade.php ENDPATH**/ ?>