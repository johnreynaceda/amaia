<span class="outline-none inline-flex justify-center items-center group rounded gap-x-1 text-xs font-semibold px-2.5 py-0.5 text-white bg-negative-500 dark:bg-negative-700" 2xs="2xs">
    
    4

    </span>
