@section('title', '')
<x-guests-layout>
    <div>
        <livewire:guest.analytic />
    </div>
</x-guests-layout>
