@section('title', 'Home')
<x-guests-layout>
    <livewire:guest.guest-dashboard />
</x-guests-layout>
