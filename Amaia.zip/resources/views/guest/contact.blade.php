<x-guests-layout>
    <div>
        <livewire:guest.contact />
    </div>
</x-guests-layout>
