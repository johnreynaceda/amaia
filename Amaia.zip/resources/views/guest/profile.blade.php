@section('title', 'My Profile')
<x-guests-layout>
    <div>
        <livewire:guest.profile />
    </div>
</x-guests-layout>
