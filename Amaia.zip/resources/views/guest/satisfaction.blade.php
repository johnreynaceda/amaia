@section('title', '')
<x-guests-layout>
    <div>
        <livewire:guest.satisfaction />
    </div>
</x-guests-layout>
