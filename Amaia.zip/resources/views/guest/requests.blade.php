@section('title', 'Requests')
<x-guests-layout>
    <div>
        <livewire:guest.request-transaction />
    </div>
</x-guests-layout>
